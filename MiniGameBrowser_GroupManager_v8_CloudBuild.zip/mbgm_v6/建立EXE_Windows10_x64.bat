@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0MiniGameBrowserGroupManager"

echo ==========================================
echo MiniGameBrowser Group Manager - Windows x64
echo ==========================================
where dotnet >nul 2>nul
if errorlevel 1 (
  echo [錯誤] 找不到 .NET SDK。
  echo 請先安裝 .NET 8 SDK x64，再重新執行本檔。
  echo 官方下載：https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)

echo.
echo [1/2] 還原 NuGet 套件...
dotnet restore
if errorlevel 1 goto failed

echo.
echo [2/2] 發佈 Windows x64 單檔 EXE...
dotnet publish -c Release -r win-x64 --self-contained true
if errorlevel 1 goto failed

echo.
echo [完成] EXE 輸出位置：
echo %cd%\bin\Release\net8.0-windows\win-x64\publish\MiniGameBrowserGroupManager.exe
echo.
echo 注意：目標電腦仍需安裝 Microsoft Edge WebView2 Runtime。
echo.
pause
exit /b 0

:failed
echo.
echo [失敗] 請將上方完整錯誤訊息提供給開發者。
pause
exit /b 1
