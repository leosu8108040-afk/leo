using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace MiniGameBrowserGroupManager;

public sealed class BrowserForm : Form
{
    private readonly Uri startUri;
    private readonly CoreWebView2Environment environment;
    private readonly WebView2 browser = new() { Dock = DockStyle.Fill };
    private readonly Action<int, Rectangle, bool> savePlacement;
    private bool restoring = true;
    private readonly int slot;
    public int SlotNumber => slot;

    public BrowserForm(
        string title,
        Uri startUri,
        CoreWebView2Environment environment,
        int groupId,
        int slot,
        SlotWindowSettings? placement,
        Action<int, Rectangle, bool> savePlacement)
    {
        Text = title;
        this.startUri = startUri;
        this.environment = environment;
        this.slot = slot;
        this.savePlacement = savePlacement;

        Width = placement?.Width ?? 470;
        Height = placement?.Height ?? 332;
        StartPosition = FormStartPosition.Manual;

        if (placement != null)
        {
            var savedBounds = new Rectangle(placement.X, placement.Y,
                Math.Max(250, placement.Width), Math.Max(180, placement.Height));
            var targetScreen = Screen.FromRectangle(savedBounds);
            var work = targetScreen.WorkingArea;
            // 若使用者拔除曾使用的第二螢幕，避免視窗還原到桌面以外而找不到。
            if (!work.IntersectsWith(savedBounds) ||
                Rectangle.Intersect(work, savedBounds).Width < 80 ||
                Rectangle.Intersect(work, savedBounds).Height < 60)
            {
                work = Screen.PrimaryScreen!.WorkingArea;
                savedBounds.X = work.X + 20;
                savedBounds.Y = work.Y + 20;
            }
            else
            {
                savedBounds.X = Math.Clamp(savedBounds.X, work.Left - savedBounds.Width + 80,
                    work.Right - 80);
                savedBounds.Y = Math.Clamp(savedBounds.Y, work.Top - savedBounds.Height + 60,
                    work.Bottom - 60);
            }
            Bounds = savedBounds;
        }
        else
        {
            var col = (slot - 1) % 4;
            var row = (slot - 1) / 4;
            Location = new Point(8 + col * 478 + ((groupId - 1) % 3) * 10,
                                 8 + row * 340 + ((groupId - 1) / 3) * 10);
        }

        Controls.Add(browser);
        Shown += (_, _) => restoring = false;
        Move += (_, _) => SavePlacement();
        Resize += (_, _) => SavePlacement();
        FormClosed += (_, _) => SavePlacement();
        if (placement?.Maximized == true)
            WindowState = FormWindowState.Maximized;
    }

    public async Task InitializeBrowserAsync()
    {
        await browser.EnsureCoreWebView2Async(environment);
        browser.CoreWebView2.Navigate(startUri.ToString());
    }

    private void SavePlacement()
    {
        if (restoring || IsDisposed) return;
        var bounds = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
        savePlacement(slot, bounds, WindowState == FormWindowState.Maximized);
    }
}
