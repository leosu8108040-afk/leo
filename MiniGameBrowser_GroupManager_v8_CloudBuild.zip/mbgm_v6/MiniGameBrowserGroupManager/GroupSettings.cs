using System.Text.Json;

namespace MiniGameBrowserGroupManager;

public sealed class GroupSettings
{
    public int SchemaVersion { get; set; } = 2;
    public string StartUrl { get; set; } = "https://ro-idle.app/";
    public List<GroupInfo> Groups { get; set; } = Enumerable.Range(1, 3)
        .Select(i => new GroupInfo { Id = i, Name = i.ToString("00") }).ToList();

    public static string SettingsPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "MiniGameBrowserGroupManager", "groups.json");

    public static GroupSettings Load()
    {
        try
        {
            if (!File.Exists(SettingsPath)) return new();

            var json = File.ReadAllText(SettingsPath);
            var loaded = JsonSerializer.Deserialize<GroupSettings>(json);
            if (loaded == null) return new();

            loaded.Groups ??= new();
            if (string.IsNullOrWhiteSpace(loaded.StartUrl))
                loaded.StartUrl = "https://ro-idle.app/";

            using var document = JsonDocument.Parse(json);
            var groupElements = document.RootElement.ValueKind == JsonValueKind.Object &&
                                document.RootElement.TryGetProperty("Groups", out var groupsElement) &&
                                groupsElement.ValueKind == JsonValueKind.Array
                ? groupsElement.EnumerateArray().ToList()
                : new List<JsonElement>();

            // 修復重複或超出範圍的組別編號，避免後續啟動時使用到錯誤的 Profile 路徑。
            var validGroups = new List<GroupInfo>();
            var usedIds = new HashSet<int>();
            foreach (var group in loaded.Groups)
            {
                if (group == null || group.Id < 1 || group.Id > 60 || !usedIds.Add(group.Id))
                    continue;

                group.Windows ??= new();
                group.SlotNames ??= new();
                var source = groupElements.FirstOrDefault(e =>
                    e.ValueKind == JsonValueKind.Object &&
                    e.TryGetProperty("Id", out var idValue) &&
                    idValue.TryGetInt32(out int parsedId) && parsedId == group.Id);
                bool hasWindowCount = source.ValueKind == JsonValueKind.Object &&
                                      source.TryGetProperty("WindowCount", out _);
                if (!hasWindowCount)
                    group.WindowCount = group.OpenFifthWindow ? 5 : 4;
                group.WindowCount = Math.Clamp(group.WindowCount, 1, 5);
                group.OpenFifthWindow = group.WindowCount == 5;
                if (string.IsNullOrWhiteSpace(group.Name))
                    group.Name = group.Id.ToString("00");

                group.SlotNames = group.SlotNames.Take(5)
                    .Select(name => name ?? string.Empty).ToList();
                group.Windows = group.Windows
                    .Where(w => w != null && w.Slot >= 1 && w.Slot <= 5)
                    .GroupBy(w => w.Slot)
                    .Select(g => g.First())
                    .ToList();
                foreach (var window in group.Windows)
                {
                    window.Width = Math.Clamp(window.Width, 250, 10000);
                    window.Height = Math.Clamp(window.Height, 180, 10000);
                }
                validGroups.Add(group);
            }
            loaded.Groups = validGroups;
            return loaded;
        }
        catch
        {
            // 設定檔損毀或格式不相容時，以預設設定啟動，避免管理器無法開啟。
            return new();
        }
    }

    public void Save()
    {
        var directory = Path.GetDirectoryName(SettingsPath)!;
        Directory.CreateDirectory(directory);
        var tempPath = SettingsPath + ".tmp";
        var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(tempPath, json);
        File.Move(tempPath, SettingsPath, true);
    }

}

public sealed class GroupInfo
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    // 每組可獨立設定 1～5 個角色視窗。
    public int WindowCount { get; set; } = 4;
    // 舊版相容欄位；載入時會與 WindowCount 同步。
    public bool OpenFifthWindow { get; set; }
    // 可自訂每個角色視窗的標題；空白時使用「角色 1」等預設名稱。
    public List<string> SlotNames { get; set; } = new();
    public List<SlotWindowSettings> Windows { get; set; } = new();
}

public sealed class SlotWindowSettings
{
    public int Slot { get; set; }
    public int X { get; set; }
    public int Y { get; set; }
    public int Width { get; set; } = 470;
    public int Height { get; set; } = 332;
    public bool Maximized { get; set; }
}
