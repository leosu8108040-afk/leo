using Microsoft.Web.WebView2.Core;

namespace MiniGameBrowserGroupManager;

public sealed class ManagerForm : Form
{
    private readonly GroupSettings settings = GroupSettings.Load();
    private readonly DataGridView grid = new();
    private readonly TextBox urlBox = new();
    private readonly Label status = new();
    private readonly Dictionary<int, List<BrowserForm>> running = new();
    private readonly Dictionary<int, CoreWebView2Environment> environments = new();
    private bool closing;

    public ManagerForm()
    {
        Text = "MiniGameBrowser 多組管理器";
        Width = 800; Height = 680;
        MinimumSize = new Size(680, 420);
        StartPosition = FormStartPosition.CenterScreen;

        var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 82, Padding = new Padding(8), WrapContents = true };
        top.Controls.Add(new Label { Text = "遊戲網址", AutoSize = true, Margin = new Padding(4, 9, 4, 0) });
        urlBox.Width = 300; urlBox.Text = settings.StartUrl;
        top.Controls.Add(urlBox);
        AddButton(top, "匯入原設定", ImportOriginalSettings);
        AddButton(top, "自動排列", TileSelected);
        AddButton(top, "排列單組", TileOneGroup);
        AddButton(top, "編輯角色名稱", EditSlotNames);
        AddButton(top, "新增組別", AddGroup);
        AddButton(top, "刪除選取", DeleteSelected);
        AddButton(top, "啟動選取", StartSelected);
        AddButton(top, "關閉選取", StopSelected);
        AddButton(top, "全部啟動", StartAll);
        AddButton(top, "全部關閉", StopAll);

        grid.Dock = DockStyle.Fill;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AutoGenerateColumns = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = true;
        grid.RowHeadersVisible = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "角色數(1-5)", Name = "WindowCount", Width = 95 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "組別編號", DataPropertyName = "Name", ReadOnly = true, Width = 110 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "狀態", Name = "State", ReadOnly = true, AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
        grid.CellValueChanged += (_, e) => { if (e.RowIndex >= 0) SaveSettings(); };
        grid.CellEndEdit += (_, e) =>
        {
            if (e.RowIndex < 0) return;
            var row = grid.Rows[e.RowIndex];
            if (row.Tag is not int id) return;
            var group = settings.Groups.FirstOrDefault(g => g.Id == id);
            if (group == null) return;
            if (!int.TryParse(Convert.ToString(row.Cells["WindowCount"].Value), out int count) || count < 1 || count > 5)
            {
                row.Cells["WindowCount"].Value = group.WindowCount;
                MessageBox.Show("每組角色數量請輸入 1 到 5。");
                return;
            }
            group.WindowCount = count;
            group.OpenFifthWindow = count == 5;
            SaveSettings();
            RefreshGrid();
        };
        grid.CurrentCellDirtyStateChanged += (_, _) => { if (grid.IsCurrentCellDirty) grid.CommitEdit(DataGridViewDataErrorContexts.Commit); };
        status.Dock = DockStyle.Bottom; status.Height = 28; status.Padding = new Padding(8, 5, 0, 0);

        Controls.Add(grid); Controls.Add(status); Controls.Add(top);
        RefreshGrid();
        urlBox.TextChanged += (_, _) => SaveSettings();
        FormClosing += (_, _) => { closing = true; StopAll(); SaveSettings(); };
    }

    private static void AddButton(Control parent, string label, Action action)
    {
        var b = new Button { Text = label, AutoSize = true, Height = 30, Margin = new Padding(3) };
        b.Click += (_, _) => action();
        parent.Controls.Add(b);
    }

    private void RefreshGrid()
    {
        if (IsDisposed) return;
        grid.Rows.Clear();
        foreach (var g in settings.Groups.OrderBy(x => x.Id))
        {
            var idx = grid.Rows.Add(g.WindowCount, g.Name, running.ContainsKey(g.Id) ? "執行中" : "未啟動");
            grid.Rows[idx].Tag = g.Id;
        }
        status.Text = $"組別：{settings.Groups.Count}/60　執行中：{running.Count} 組";
    }


    private void ImportOriginalSettings()
    {
        using var dialog = new OpenFileDialog
        {
            Title = "選擇原本的 settings.json",
            Filter = "JSON 設定檔 (*.json)|*.json|所有檔案 (*.*)|*.*",
            CheckFileExists = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(File.ReadAllText(dialog.FileName));
            var root = doc.RootElement;
            if (!root.TryGetProperty("Windows", out var windows) ||
                windows.ValueKind != System.Text.Json.JsonValueKind.Object)
                throw new InvalidDataException("找不到 Windows 設定區塊。");

            var letterToGroup = new Dictionary<string, int> { ["A"] = 1, ["B"] = 2, ["C"] = 3 };
            foreach (var pair in letterToGroup)
            {
                var group = settings.Groups.FirstOrDefault(g => g.Id == pair.Value);
                if (group == null)
                {
                    group = new GroupInfo { Id = pair.Value, Name = pair.Value.ToString("00") };
                    settings.Groups.Add(group);
                }

                for (int slot = 1; slot <= 4; slot++)
                {
                    string key = pair.Key + slot;
                    if (!windows.TryGetProperty(key, out var item) ||
                        item.ValueKind != System.Text.Json.JsonValueKind.Object) continue;

                    var placement = group.Windows.FirstOrDefault(w => w.Slot == slot);
                    if (placement == null)
                    {
                        placement = new SlotWindowSettings { Slot = slot };
                        group.Windows.Add(placement);
                    }
                    placement.X = ReadInt(item, "X", placement.X);
                    placement.Y = ReadInt(item, "Y", placement.Y);
                    placement.Width = Math.Max(250, ReadInt(item, "Width", 470));
                    placement.Height = Math.Max(180, ReadInt(item, "Height", 332));
                    placement.Maximized = ReadBool(item, "Maximized", false);
                }
            }

            if (root.TryGetProperty("OpenFifthWindow", out var fifth) &&
                fifth.ValueKind == System.Text.Json.JsonValueKind.Object)
            {
                foreach (var pair in new[] { ("A", 1), ("B", 2) })
                {
                    var group = settings.Groups.First(g => g.Id == pair.Item2);
                    if (fifth.TryGetProperty(pair.Item1, out var enabled) &&
                        (enabled.ValueKind == System.Text.Json.JsonValueKind.True ||
                         enabled.ValueKind == System.Text.Json.JsonValueKind.False))
                    {
                        group.OpenFifthWindow = enabled.GetBoolean();
                        group.WindowCount = group.OpenFifthWindow ? 5 : 4;
                    }
                }
            }

            if (root.TryGetProperty("StartUrl", out var url) &&
                url.ValueKind == System.Text.Json.JsonValueKind.String)
                urlBox.Text = url.GetString() ?? settings.StartUrl;

            SaveSettings();
            RefreshGrid();
            MessageBox.Show("已匯入 A/B/C 三組的視窗座標及原設定提供的第五視窗旗標。",
                "匯入完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"匯入失敗：{ex.Message}", "設定檔錯誤",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static int ReadInt(System.Text.Json.JsonElement element, string name, int fallback)
    {
        return element.TryGetProperty(name, out var value) && value.TryGetInt32(out int result)
            ? result : fallback;
    }

    private static bool ReadBool(System.Text.Json.JsonElement element, string name, bool fallback)
    {
        return element.TryGetProperty(name, out var value) &&
               (value.ValueKind == System.Text.Json.JsonValueKind.True ||
                value.ValueKind == System.Text.Json.JsonValueKind.False)
            ? value.GetBoolean() : fallback;
    }


    private static string GetSlotName(GroupInfo group, int slot)
    {
        if (slot >= 1 && slot <= group.SlotNames.Count &&
            !string.IsNullOrWhiteSpace(group.SlotNames[slot - 1]))
            return group.SlotNames[slot - 1].Trim();
        return $"角色 {slot}";
    }

    private void EditSlotNames()
    {
        var ids = SelectedIds();
        if (ids.Count != 1)
        {
            MessageBox.Show("請只選取一個組別，再編輯該組角色名稱。");
            return;
        }

        var group = settings.Groups.FirstOrDefault(g => g.Id == ids[0]);
        if (group == null) return;

        using var dialog = new Form
        {
            Text = $"編輯 {group.Name} 組角色名稱",
            Width = 390,
            Height = 360,
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false,
            MinimizeBox = false
        };
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(12),
            ColumnCount = 2,
            RowCount = 6
        };
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        var editors = new TextBox[5];
        for (int i = 0; i < 5; i++)
        {
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            panel.Controls.Add(new Label
            {
                Text = $"角色 {i + 1}",
                AutoSize = true,
                Anchor = AnchorStyles.Left,
                Margin = new Padding(3, 10, 3, 3)
            }, 0, i);
            editors[i] = new TextBox
            {
                Dock = DockStyle.Fill,
                MaxLength = 40,
                Text = i < group.SlotNames.Count ? group.SlotNames[i] : ""
            };
            editors[i].PlaceholderText = $"留空則顯示「角色 {i + 1}」";
            panel.Controls.Add(editors[i], 1, i);
        }

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft,
            Padding = new Padding(0, 8, 0, 0)
        };
        var save = new Button { Text = "儲存", DialogResult = DialogResult.OK, Width = 80 };
        var cancel = new Button { Text = "取消", DialogResult = DialogResult.Cancel, Width = 80 };
        buttons.Controls.Add(save);
        buttons.Controls.Add(cancel);
        panel.Controls.Add(buttons, 0, 5);
        panel.SetColumnSpan(buttons, 2);
        dialog.Controls.Add(panel);
        dialog.AcceptButton = save;
        dialog.CancelButton = cancel;

        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        group.SlotNames = editors.Select(e => e.Text.Trim()).ToList();
        SaveSettings();
        MessageBox.Show("角色名稱已儲存。重新啟動該組視窗後會套用新標題。",
            "儲存完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void TileOneGroup()
    {
        var ids = SelectedIds();
        if (ids.Count != 1)
        {
            MessageBox.Show("請只選取一個組別，才能單獨排列該組視窗。");
            return;
        }
        TileGroups(new[] { ids[0] });
    }

    private void TileSelected()
    {
        var ids = SelectedIds();
        if (ids.Count == 0)
        {
            MessageBox.Show("請先選取要排列的組別。");
            return;
        }
        TileGroups(ids);
    }

    private void TileGroups(IEnumerable<int> groupIds)
    {
        var forms = groupIds.Where(running.ContainsKey)
            .SelectMany(id => running[id]).Where(f => !f.IsDisposed).ToList();
        if (forms.Count == 0)
        {
            MessageBox.Show("選取的組別目前沒有啟動中的視窗。");
            return;
        }

        // 依照每個視窗目前所在的螢幕分開排列，避免多螢幕使用者按下排列後，
        // 所有視窗都被搬到第一個視窗所在的螢幕。
        foreach (var screenGroup in forms.GroupBy(f => Screen.FromControl(f).DeviceName))
        {
            var screen = Screen.AllScreens.FirstOrDefault(s => s.DeviceName == screenGroup.Key)
                         ?? Screen.PrimaryScreen!;
            var area = screen.WorkingArea;
            var screenForms = screenGroup.ToList();
            int columns = Math.Max(1, (int)Math.Ceiling(
                Math.Sqrt(screenForms.Count * (double)area.Width / area.Height)));
            int rows = (int)Math.Ceiling(screenForms.Count / (double)columns);
            int cellWidth = Math.Max(1, area.Width / columns);
            int cellHeight = Math.Max(1, area.Height / rows);

            for (int i = 0; i < screenForms.Count; i++)
            {
                var form = screenForms[i];
                form.WindowState = FormWindowState.Normal;
                int col = i % columns;
                int row = i / columns;
                int x = area.X + col * cellWidth;
                int y = area.Y + row * cellHeight;
                int width = Math.Min(cellWidth, area.Right - x);
                int height = Math.Min(cellHeight, area.Bottom - y);
                form.Bounds = new Rectangle(x, y, Math.Max(1, width), Math.Max(1, height));
            }
        }
    }

    private void AddGroup()
    {
        if (settings.Groups.Count >= 60) { MessageBox.Show("最多只能建立 60 組。"); return; }
        var id = Enumerable.Range(1, 60).First(n => settings.Groups.All(g => g.Id != n));
        settings.Groups.Add(new GroupInfo { Id = id, Name = id.ToString("00"), WindowCount = 4 });
        SaveSettings(); RefreshGrid();
    }

    private void DeleteSelected()
    {
        var ids = SelectedIds();
        if (ids.Count == 0) return;
        if (MessageBox.Show($"確定刪除 {ids.Count} 個組別？組別的視窗位置設定會一併刪除。", "確認刪除",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        foreach (var id in ids)
        {
            StopGroup(id);
            settings.Groups.RemoveAll(g => g.Id == id);
        }
        SaveSettings(); RefreshGrid();
    }

    private List<int> SelectedIds() => grid.SelectedRows.Cast<DataGridViewRow>()
        .Select(r => (int)r.Tag!).Distinct().ToList();

    private async void StartSelected()
    {
        foreach (var id in SelectedIds()) await StartGroup(id);
        RefreshGrid();
    }

    private void StopSelected()
    {
        foreach (var id in SelectedIds()) StopGroup(id);
        RefreshGrid();
    }

    private async void StartAll()
    {
        foreach (var group in settings.Groups.OrderBy(g => g.Id)) await StartGroup(group.Id);
        RefreshGrid();
    }

    private void StopAll()
    {
        foreach (var id in running.Keys.ToList()) StopGroup(id);
        RefreshGrid();
    }

    private async Task StartGroup(int id)
    {
        var group = settings.Groups.FirstOrDefault(g => g.Id == id);
        if (group == null) return;
        if (!Uri.TryCreate(urlBox.Text.Trim(), UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
        { MessageBox.Show("請輸入有效的 http 或 https 網址。"); return; }

        try
        {
            CoreWebView2Environment env;
            if (environments.TryGetValue(id, out var existingEnvironment))
            {
                env = existingEnvironment;
            }
            else
            {
                var profile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "MiniGameBrowserGroupManager", "Profiles", $"Group-{id:00}");
                Directory.CreateDirectory(profile);
                env = await CoreWebView2Environment.CreateAsync(null, profile);
                environments[id] = env;
            }

            if (!running.TryGetValue(id, out var forms))
            {
                forms = new List<BrowserForm>();
                running[id] = forms;
            }
            var activeSlots = forms.Where(f => !f.IsDisposed).Select(f => f.SlotNumber).ToHashSet();
            int count = Math.Clamp(group.WindowCount, 1, 5);
            for (int slot = 1; slot <= count; slot++)
            {
                if (activeSlots.Contains(slot)) continue;
                var placement = group.Windows.FirstOrDefault(w => w.Slot == slot);
                string slotName = GetSlotName(group, slot);
                var form = new BrowserForm($"組別 {group.Name} - {slotName}", uri, env, id, slot,
                    placement, (slotNumber, bounds, maximized) => SaveWindowPlacement(id, slotNumber, bounds, maximized));
                forms.Add(form);
                form.FormClosed += (_, _) =>
                {
                    if (running.TryGetValue(id, out var list))
                    {
                        list.Remove(form);
                        if (list.Count == 0)
                        {
                            running.Remove(id);
                            environments.Remove(id);
                        }
                    }
                    if (!closing && !IsDisposed && IsHandleCreated)
                        BeginInvoke(new Action(RefreshGrid));
                };
                form.Show();
                await form.InitializeBrowserAsync();
            }
            RefreshGrid();
        }
        catch (Exception ex)
        {
            StopGroup(id);
            MessageBox.Show($"啟動 {group.Name} 組失敗：{ex.Message}", "啟動錯誤");
        }
    }

    private void SaveWindowPlacement(int groupId, int slot, Rectangle bounds, bool maximized)
    {
        var group = settings.Groups.FirstOrDefault(g => g.Id == groupId);
        if (group == null) return;
        var item = group.Windows.FirstOrDefault(w => w.Slot == slot);
        if (item == null)
        {
            item = new SlotWindowSettings { Slot = slot };
            group.Windows.Add(item);
        }
        item.X = bounds.X; item.Y = bounds.Y;
        item.Width = Math.Max(250, bounds.Width);
        item.Height = Math.Max(180, bounds.Height);
        item.Maximized = maximized;
        settings.Save();
    }

    private void StopGroup(int id)
    {
        if (!running.TryGetValue(id, out var forms)) return;
        running.Remove(id);
        foreach (var f in forms.ToList()) if (!f.IsDisposed) f.Close();
        environments.Remove(id);
    }

    private void SaveSettings()
    {
        settings.StartUrl = urlBox.Text.Trim();
        foreach (DataGridViewRow row in grid.Rows)
        {
            if (row.Tag is int id)
            {
                var g = settings.Groups.FirstOrDefault(x => x.Id == id);
                if (g != null && int.TryParse(Convert.ToString(row.Cells["WindowCount"].Value), out int count))
                {
                    g.WindowCount = Math.Clamp(count, 1, 5);
                    g.OpenFifthWindow = g.WindowCount == 5;
                }
            }
        }
        settings.Save();
    }
}
