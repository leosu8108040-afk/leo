MiniGameBrowser 多組管理器 - 第二版原始碼原型

目標環境：Windows 10 22H2 x64
架構：.NET 8 Windows Forms + Microsoft WebView2

第四版功能：
- 01～60 組新增/刪除（自動使用最小可用編號）
- 單組啟動、關閉；全部啟動、關閉
- 每組預設 4 個角色視窗，可勾選開啟第 5 個
- 每組使用獨立 WebView2 User Data Folder：
  %LOCALAPPDATA%\\MiniGameBrowserGroupManager\\Profiles\\Group-XX
- 同一組內的角色視窗共用該組 WebView2 環境；不同組別隔離 Cookie 與網站資料
- 設定存於：
  %LOCALAPPDATA%\\MiniGameBrowserGroupManager\\groups.json
- 記住每個組別每個角色視窗的位置、尺寸及最大化狀態\n- 可選取原始 settings.json，將 A/B/C 對應匯入為 01/02/03 組，匯入 A1～C4 座標尺寸及原始 OpenFifthWindow 中的 A/B 旗標\n- 可對已啟動的選取組別執行桌面自動排列
- 每個組別可獨立設定 1～5 個角色視窗，不再固定全部組別都是 4 個或 5 個
- 管理表格可直接修改各組角色數量；舊版設定會自動轉換，舊的第五視窗勾選設定仍可相容
- 關閉再啟動時會嘗試還原視窗位置

建置：
1. Windows 10 22H2 x64 安裝 .NET 8 SDK。
2. 解壓縮後進入 MiniGameBrowserGroupManager 資料夾。
3. 執行 dotnet restore
4. 執行 dotnet build -c Release
5. 執行檔位於 bin\\Release\\net8.0-windows\\

重要限制：
這是獨立重建的管理器原型，不是原作者 MiniGameBrowser 的修改版。
本執行環境無法執行 Windows 桌面程式或完成 Windows 端編譯測試。
尚未驗證遊戲網站在多個 WebView2 視窗中的相容性。
目前不會讀取原程式 settings.json，也不會移轉原程式既有登入資料。
原程式 settings.json 的四個視窗座標與第五視窗旗標尚未自動匯入。
目前第五視窗是管理器新設計的第 5 個瀏覽器視窗，並非證實與原程式原生第五角色完全相同。
若遊戲網站本身限制多開或要求額外驗證，管理器無法繞過網站限制。

匯入說明：
- 原設定中的 A、B、C 對應新管理器 01、02、03 組。
- A1～A4、B1～B4、C1～C4 的座標、尺寸、最大化狀態會匯入對應角色視窗。
- 原始 OpenFifthWindow 只有 A、B 旗標，因此只會匯入 01、02 組的第五視窗設定；03 組及其他新增組別不會被推定有原生第五視窗設定。
- 匯入功能不會搬移原本 WebView2 的 Cookie 或登入資料。
- 自動排列會改變目前視窗位置，位置變更會自動保存；要恢復原始位置，可再次匯入原設定檔。

第四版角色數量設定：
- 管理表格「角色數(1-5)」欄位可逐組輸入 1～5。
- 例如 01 組可設 2 個、02 組可設 5 個、03 組可設 3 個，互不影響。
- 這是管理器自行建立的角色視窗數量設定，不代表原始 MiniGameBrowser 已驗證支援任意數量視窗。
- 若正在執行某組，修改數量不會即時增減已開啟視窗；請先關閉該組，再重新啟動，才會套用新數量。

注意：第四版原始碼已補齊「匯入原設定」與「自動排列」按鈕所呼叫的方法。此版本仍未在 Windows/.NET SDK 環境實際編譯，請先依建置說明編譯後測試。

第五版新增功能：
- 每組可自訂最多 5 個角色視窗標題。選取單一組別後按「編輯角色名稱」，留空則使用預設的「角色 1」等名稱。
- 新增「排列單組」按鈕，只會排列目前選取的單一組別，不會移動其他組別的視窗。
- 原本「自動排列」仍可一次排列多個選取組別。
- 排列時以該組第一個視窗所在螢幕的工作區作為範圍；不會刻意將其他螢幕的視窗也挪動到主要螢幕。
- 角色名稱儲存在管理器 groups.json；更改名稱後，已開啟的視窗標題不會即時改變，重新啟動該組後生效。

第六版：Windows EXE 發佈設定
========================================
本版新增「建立EXE_Windows10_x64.bat」及 .NET 8 win-x64 自包含單檔發佈設定。

在 Windows 10 22H2 電腦上：
1. 解壓縮整個 ZIP。
2. 安裝 .NET 8 SDK x64（不是只有 Runtime）。
3. 執行「建立EXE_Windows10_x64.bat」。
4. 成功後，EXE 會位於：
   MiniGameBrowserGroupManager\bin\Release\net8.0-windows\win-x64\publish\
5. 將 publish 資料夾中的程式帶到目標電腦執行。

重要：
- 本專案仍需要網路還原 Microsoft.Web.WebView2 NuGet 套件；首次建置請保持網路連線。
- 目標電腦仍需安裝 Microsoft Edge WebView2 Evergreen Runtime。自包含發佈只包含 .NET 執行環境，不會把 WebView2 Runtime 一起包進 EXE。
- 單檔發佈可能在首次啟動時解壓部分原生元件。
- 此環境無法執行 Windows/.NET SDK 編譯，因此本 ZIP 提供可在 Windows 執行的建置腳本，並非已編譯、已測試的 EXE。
- 若建置失敗，請把命令視窗中的完整錯誤文字或截圖傳回，以便針對錯誤修正。


第七版：GitHub 雲端 Windows 自動編譯
========================================
如果無法在自己的電腦安裝 .NET SDK，可使用 GitHub Actions 的 Windows 編譯環境。

需要：
- 一個 GitHub 帳號。
- 建立一個新的 Private repository（私人儲存庫），避免公開專案原始碼。
- 將本 ZIP 解壓縮後的所有檔案及 .github 資料夾上傳到該 repository 的根目錄。

操作：
1. 登入 GitHub，建立 New repository，建議選 Private。
2. 將解壓後的所有檔案上傳至 repository 根目錄並 Commit changes。
3. 開啟 repository 上方的 Actions 分頁。
4. 左側選擇「Build Windows EXE」。
5. 按右側「Run workflow」，再按綠色的「Run workflow」確認。
6. 等待工作流程完成（綠色勾勾）。
7. 在該次執行頁面下方 Artifacts 區域，下載 MiniGameBrowserGroupManager-win-x64。
8. 解壓 Artifact ZIP，執行 MiniGameBrowserGroupManager.exe。

每次手動 Run workflow 都會重新編譯；推送 v* 標籤也會自動編譯。
編譯結果 Artifact 保留 30 天，請在期限內下載。

重要限制：
- GitHub Actions 是雲端 Windows 編譯，不等於已在你的實際 Windows 10 電腦完成相容性測試。
- 此專案需要 NuGet 網路連線；GitHub runner 會在編譯時還原套件。
- 目標電腦仍須安裝 Microsoft Edge WebView2 Evergreen Runtime。
- 請勿將含有私人資料、登入 Cookie 或帳密的檔案上傳到 repository。
- GitHub 帳號及上傳/執行 workflow 的步驟仍需要由你操作；我無法代替你登入或操作你的 GitHub 帳號。

第八版：多螢幕排列與視窗還原修正
========================================
- 自動排列改為依視窗目前所在螢幕分開排列，不再把不同螢幕上的視窗全部搬到第一個螢幕。
- 還原視窗位置時，若原本使用的螢幕已不存在，會將視窗移回主要螢幕，降低視窗出現在桌面外而無法操作的情況。
- GitHub Actions 工作流程增加獨立 Release 編譯步驟、環境資訊及建置逾時限制；若編譯失敗，可在 Actions 工作紀錄中看到較明確的錯誤階段。

本版仍未取得 Windows 編譯環境，不能宣稱已產生或測試成功的 EXE。要取得真正的 Windows EXE，仍須由 GitHub Actions 執行這份工作流程。
